
<#
Used to get resource mailbox resources
Josh Hensley 11.17.2017
#>

Get-resourceconfig | fl

